// Функция для генерации случайного пароля
function generatePassword(length) {
    let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; // По умолчанию только буквы
    const includeNumbers = document.getElementById("include-numbers").checked;
    const includeSymbols = document.getElementById("include-symbols").checked;

    if (includeNumbers) chars += "0123456789";
    if (includeSymbols) chars += "!@#$%^&*()";

    let password = "";
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}

// Обновляем отображение длины при изменении ползунка
const lengthInput = document.getElementById("length");
const lengthValue = document.getElementById("lengthValue");

lengthInput.addEventListener("input", function () {
    lengthValue.textContent = this.value;   
});

// Обработчик кнопки "Сгенерировать"
document.getElementById("generate").addEventListener("click", function () {
    const length = parseInt(lengthInput.value);
    if (!length || length < 8 || length > 20) {
        alert("Ошибка: длина пароля должна быть от 8 до 20 символов.");
        return;
    }

    const password = generatePassword(length);
    document.getElementById("password").value = password;
});

// Обработчик кнопки "Сохранить пароль"
document.getElementById("save").addEventListener("click", function () {
    const site = document.getElementById("site").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!site || !password) {
        alert("Введите сайт и сгенерируйте пароль!");
        return;
    }

    chrome.storage.local.get({ passwords: [] }, function (data) {
        let passwords = data.passwords;

        // Проверяем, существует ли уже пароль для данного сайта
        const existingIndex = passwords.findIndex(p => p.site === site);

        if (existingIndex !== -1) {
            // Если сайт уже есть, заменяем пароль
            passwords[existingIndex].password = password;
        } else {
            // Если сайта ещё нет, добавляем новый пароль
            passwords.push({ site, password });
        }

        // Сохраняем обновлённый список паролей
        chrome.storage.local.set({ passwords }, function () {
            updatePasswordList();
            document.getElementById("site").value = "";
            document.getElementById("password").value = "";
        });
    });
});

// Функция для обновления списка сохраненных паролей
function updatePasswordList(filter = "") {
    chrome.storage.local.get({ passwords: [] }, function (data) {
        const passwords = data.passwords.filter(p => p.site.toLowerCase().includes(filter.toLowerCase()));
        const list = document.getElementById("passwords");
        list.innerHTML = passwords.length === 0 ? "<p>Паролей пока нет</p>" : "";

        passwords.forEach((item) => {
            const div = document.createElement("div");
            div.className = "password-item";
            div.innerHTML = `
                <div class="password-left">
                    <button class="toggle-password" data-site="${item.site}">
                        <img src="eye-icon.png" alt="👁">
                    </button>
                    <span class="password-site">${item.site}</span>
                    <span class="hidden-password" data-site="${item.site}">******</span>
                </div>
                <div class="password-right">
                    <button class="copy-btn" data-site="${item.site}">📋</button>
                    <button class="delete-btn" data-site="${item.site}">🗑</button>
                </div>
            `;
            list.appendChild(div);
        });
        

        // Добавляем обработчики для кнопок "глазика"
        document.querySelectorAll(".toggle-password").forEach(button => {
            button.addEventListener("click", function () {
                const site = this.getAttribute("data-site");
                const passwordSpan = document.querySelector(`.hidden-password[data-site="${site}"]`);

                chrome.storage.local.get({ passwords: [] }, function (data) {
                    const storedPassword = data.passwords.find(p => p.site === site)?.password || "******";
                    passwordSpan.textContent = (passwordSpan.textContent === "******") ? storedPassword : "******";
                });
            });
        });

        // Кнопки копирования
        document.querySelectorAll(".copy-btn").forEach(button => {
            button.addEventListener("click", function () {
                const site = this.getAttribute("data-site");
                chrome.storage.local.get({ passwords: [] }, function (data) {
                    const password = data.passwords.find(p => p.site === site)?.password;
                    if (password) {
                        navigator.clipboard.writeText(password).then(() => {
                            alert("Пароль скопирован!");
                        });
                    }
                });
            });
        });

        // Кнопки удаления
        document.querySelectorAll(".delete-btn").forEach(button => {
            button.addEventListener("click", function () {
                const site = this.getAttribute("data-site");
                deletePassword(site);
            });
        });
    });
}

// Функция удаления пароля
function deletePassword(site) {
    chrome.storage.local.get({ passwords: [] }, function (data) {
        let passwords = data.passwords.filter(p => p.site !== site);
        chrome.storage.local.set({ passwords: passwords }, function () {
            updatePasswordList();
        });
    });
}

// Загружаем список паролей при запуске
updatePasswordList();

// Функция переключения темы
const themeToggle = document.getElementById("theme-toggle");

themeToggle.addEventListener("change", function () {
    if (this.checked) {
        document.body.classList.add("dark-theme");
        chrome.storage.local.set({ theme: "dark" });
    } else {
        document.body.classList.remove("dark-theme");
        chrome.storage.local.set({ theme: "light" });
    }
});

function exportPasswords() {
  chrome.storage.local.get({ passwords: [] }, (result) => {
    const blob = new Blob([JSON.stringify(result.passwords, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'passwords_backup.json';
    a.click();
    URL.revokeObjectURL(url);
    alert('Экспорт завершён');
  });
}

function importPasswords(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      if (Array.isArray(imported)) {
        chrome.storage.local.set({ passwords: imported }, () => {
          updatePasswordList();
          alert('Импорт завершён');
        });
      } else {
        alert('Файл должен содержать массив записей');
      }
    } catch (e) {
      alert('Ошибка при чтении файла: ' + e.message);
    }
  };
  reader.readAsText(file);
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('exportBtn').addEventListener('click', exportPasswords);
  document.getElementById('importFile').addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      importPasswords(e.target.files[0]);
    }
  });
});


// Загружаем сохранённую тему при запуске
chrome.storage.local.get("theme", function (data) {
    if (data.theme === "dark") {
        document.body.classList.add("dark-theme");
        themeToggle.checked = true;
    }
});

document.getElementById("search").addEventListener("input", function () {
    updatePasswordList(this.value);
});
